/*
  app.js — GrowthHub Mini App
  Complete frontend logic for the redesigned UI.
*/

const tg = window.Telegram.WebApp;
tg.ready();
tg.expand();

function copyToClipboard(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }
  return new Promise((resolve, reject) => {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0;";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { document.execCommand("copy"); resolve(); }
    catch(e) { reject(e); }
    finally { document.body.removeChild(ta); }
  });
}

function showToast(iconEl) {
  const toast = document.createElement("div");
  toast.className = "copy-toast";
  toast.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="20 6 9 17 4 12"/></svg>`;
  const rect = iconEl.getBoundingClientRect();
  toast.style.left = rect.left + rect.width / 2 - 12 + "px";
  toast.style.top = rect.top - 28 + "px";
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 800);
}

document.body.addEventListener("click", (e) => {
  const icon = e.target.closest(".copy-icon[data-copy]");
  if (!icon) return;
  e.stopPropagation();
  e.preventDefault();
  const text = icon.getAttribute("data-copy");
  if (!text) return;
  copyToClipboard(text).then(() => showToast(icon)).catch(() => {});
});

const AVATAR_COLORS = ["#0F9B8E", "#14213D", "#FCA311", "#4A6FA5", "#E91E63", "#2ECC71"];

function colorForName(name) {
  let hash = 0;
  for (const char of name || "") hash = (hash * 31 + char.charCodeAt(0)) % AVATAR_COLORS.length;
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function initials(name) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || "") + (parts[1]?.[0] || "")).toUpperCase() || name[0].toUpperCase();
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function renderSocialPlatformsDisplay(profile) {
  let platforms = [];
  if (profile.social_platforms) {
    try {
      const parsed = typeof profile.social_platforms === "string"
        ? JSON.parse(profile.social_platforms)
        : profile.social_platforms;
      if (Array.isArray(parsed)) platforms = parsed;
    } catch(e) {}
  }
  if (!platforms.length) return "";

  const platDefs = {
    instagram: { label: "Instagram", color: "#E4405F",
      svg: `<svg viewBox="0 0 24 24" fill="#E4405F"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>` },
    twitter: { label: "X", color: "#000000", lightBg: true,
      svg: `<svg viewBox="0 0 24 24" fill="#000000"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>` },
    facebook: { label: "Facebook", color: "#1877F2",
      svg: `<svg viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>` },
    linkedin: { label: "LinkedIn", color: "#0A66C2",
      svg: `<svg viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>` },
    youtube: { label: "YouTube", color: "#FF0000",
      svg: `<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>` },
  };

  const tagsHtml = platforms.map(sp => {
    const def = platDefs[sp.platform];
    if (!def) return "";
    const isLight = def.lightBg;
    const bgColor = isLight ? "#FFFFFF" : `${def.color}12`;
    const borderColor = isLight ? "#E0E0E0" : `${def.color}30`;
    const textColor = isLight ? "#333333" : def.color;
    return `<span class="social-tag" style="background:${bgColor};color:${textColor};border:1px solid ${borderColor};">
      <span class="social-tag-icon">${def.svg}</span>
      <span class="social-tag-label">${escapeHtml(def.label)}</span>
      <span class="social-tag-handle">${escapeHtml(sp.handle || "")}</span>
      <button class="copy-icon" data-copy="${escapeHtml(sp.handle || "")}" aria-label="Copy"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
    </span>`;
  }).filter(Boolean).join("");

  if (!tagsHtml) return "";

  return `
    <div class="detail-section">
      <div class="detail-section-title">Social Media</div>
      <div class="social-tags-wrap">${tagsHtml}</div>
    </div>`;
}

function photoUrl(entrepreneurId) {
  return `/api/photo/${entrepreneurId}?initData=${encodeURIComponent(tg.initData)}`;
}

// ---- Location ----
let userLat = null;
let userLng = null;

function requestUserLocation() {
  if (!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      userLat = pos.coords.latitude;
      userLng = pos.coords.longitude;
      localStorage.setItem("gh_lat", userLat);
      localStorage.setItem("gh_lng", userLng);
    },
    () => {},
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
  );
}

function loadSavedLocation() {
  const lat = localStorage.getItem("gh_lat");
  const lng = localStorage.getItem("gh_lng");
  if (lat && lng) {
    userLat = parseFloat(lat);
    userLng = parseFloat(lng);
  }
}

loadSavedLocation();
requestUserLocation();

// Generic "no photo" placeholder — a plain person silhouette, used
// anywhere someone hasn't uploaded a real photo. Used to fall back to
// showing initials as text instead, which read as a rendering bug more
// than a deliberate design choice.
function noPhotoIconHtml() {
  return `<svg viewBox="0 0 24 24" fill="none" style="width:55%;height:55%;"><circle cx="12" cy="8" r="4" stroke="currentColor" stroke-width="2"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;
}

// Category pill icons — hand-drawn outline SVGs (same stroke-based style
// as the bottom nav icons) instead of emoji, which rendered small and
// inconsistently across devices. One shared accent color for every icon
// (set via CSS on the wrapping circle, not per-category) so the row
// reads as one consistent set rather than a handful of random colors.
const CATEGORY_ICON_PATHS = {
  "home services": '<path d="M4 11 12 4l8 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 10v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  "digital services": '<rect x="3" y="5" width="18" height="12" rx="1.5" stroke="currentColor" stroke-width="2"/><path d="M8 21h8M12 17v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
  "creative": '<path d="M12 21a9 9 0 1 1 0-18c4.5 0 8 2.5 8 6.5 0 2-1.5 3.5-3.5 3.5H15a1.7 1.7 0 0 0-1 3c0 1.5-1 2.5-2 3v2z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="7.5" cy="10.5" r="1" fill="currentColor"/><circle cx="10.5" cy="7" r="1" fill="currentColor"/><circle cx="15" cy="7.5" r="1" fill="currentColor"/>',
  "health & wellness": '<path d="M20.8 8.6c0 4.5-8.8 10.4-8.8 10.4S3.2 13.1 3.2 8.6a4.6 4.6 0 0 1 8.8-1.8 4.6 4.6 0 0 1 8.8 1.8Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
  "education": '<path d="M3 8 12 4l9 4-9 4-9-4Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M7 11v5c0 1 2 2.5 5 2.5s5-1.5 5-2.5v-5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
  "food & catering": '<path d="M6 3v7a2 2 0 0 0 4 0V3M8 3v18M17 3c-1.5 0-3 2-3 6s1.5 6 3 6 3-2 3-6-1.5-6-3-6Zm0 12v6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  "transport": '<rect x="3" y="10" width="18" height="7" rx="1.5" stroke="currentColor" stroke-width="2"/><path d="M5 10l2-5h10l2 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="7.5" cy="17.5" r="1.5" stroke="currentColor" stroke-width="2"/><circle cx="16.5" cy="17.5" r="1.5" stroke="currentColor" stroke-width="2"/>',
  "fashion & beauty": '<path d="M8 4 4 8l4 3 1-2v11h6V9l1 2 4-3-4-4-3 2-3-2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
  "repair & maintenance": '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2-2 2.5-2.5Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
  "other": '<rect x="4" y="4" width="7" height="7" rx="1" stroke="currentColor" stroke-width="2"/><rect x="13" y="4" width="7" height="7" rx="1" stroke="currentColor" stroke-width="2"/><rect x="4" y="13" width="7" height="7" rx="1" stroke="currentColor" stroke-width="2"/><rect x="13" y="13" width="7" height="7" rx="1" stroke="currentColor" stroke-width="2"/>',
};
const DEFAULT_CATEGORY_ICON_PATH = CATEGORY_ICON_PATHS.other;

function categoryIconHtml(categoryName) {
  const key = (categoryName || "").trim().toLowerCase();
  const pathData = CATEGORY_ICON_PATHS[key] || DEFAULT_CATEGORY_ICON_PATH;
  return `<svg viewBox="0 0 24 24" fill="none" style="width:16px;height:16px;">${pathData}</svg>`;
}

function avatarHtml(entrepreneur, size) {
  const style = size ? `width:${size}px;height:${size}px;font-size:${size * 0.34}px;` : "";
  if (entrepreneur.id && (entrepreneur.photo_base64 || entrepreneur.photo_file_id)) {
    return `<div class="avatar-circle" style="${style}"><img src="${photoUrl(entrepreneur.id)}" alt="" onerror="this.remove()"></div>`;
  }
  return `<div class="avatar-circle" style="background:${colorForName(entrepreneur.name)};${style}display:flex;align-items:center;justify-content:center;color:white;">${noPhotoIconHtml()}</div>`;
}

// ---- API helpers ----
async function apiGet(path) {
  const separator = path.includes("?") ? "&" : "?";
  const res = await fetch(`${path}${separator}initData=${encodeURIComponent(tg.initData)}`);
  return res.json().catch(() => ({}));
}

function asArray(data) {
  return Array.isArray(data) ? data : [];
}

async function apiPost(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return { ok: res.ok, status: res.status, data: await res.json().catch(() => ({})) };
}

// tg.showConfirm() requires Bot API 6.2+ — on an older Telegram client
// it's either undefined or silently does nothing (no dialog, callback
// never fires), which looks exactly like "the button does nothing" from
// the outside, since the actual request only ever gets sent inside that
// callback. tg.showAlert already gets this same defensive treatment
// elsewhere in this file; showConfirm never did until now.
function safeConfirm(message, callback) {
  const supported = tg.showConfirm && (!tg.isVersionAtLeast || tg.isVersionAtLeast("6.2"));
  if (supported) {
    try {
      tg.showConfirm(message, callback);
      return;
    } catch (e) {
      console.error("tg.showConfirm threw, falling back to window.confirm:", e);
    }
  }
  callback(window.confirm(message));
}

function safeAlert(message) {
  if (tg.showAlert) {
    try { tg.showAlert(message); return; } catch (e) { console.error("tg.showAlert threw:", e); }
  }
  alert(message);
}

function emptyState(message) {
  return `
    <div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/><path d="M8 15s1.5-2 4-2 4 2 4 2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="9" y1="9" x2="9.01" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><line x1="15" y1="9" x2="15.01" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      <p>${message}</p>
    </div>`;
}

// ============================================================
// Navigation
// ============================================================
let currentView = "home";

function showView(name) {
  if (name !== "stepper" && name !== "success" && name !== "admin" && currentUserType === null) {
    openStepper(null);
    return;
  }
  if (name === "stepper") {
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    document.getElementById("view-stepper").classList.add("active");
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    currentView = name;
    return;
  }
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.getElementById(`view-${name}`).classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
  const navBtn = document.querySelector(`.nav-btn[data-nav="${name}"]`);
  if (navBtn) navBtn.classList.add("active");
  currentView = name;

  if (name === "home") loadHome();
  if (name === "explore") loadExplore();
  if (name === "jobs") loadJobs();
  if (name === "favorites") loadFavorites();
  if (name === "profile") loadProfile();
  if (name === "admin") loadAdminPanel();
}

document.querySelectorAll("[data-nav]").forEach(btn => {
  btn.addEventListener("click", () => showView(btn.dataset.nav));
});
document.querySelectorAll("[data-goto]").forEach(el => {
  el.addEventListener("click", () => showView(el.dataset.goto));
});

// ============================================================
// HOME
// ============================================================
async function loadHome() {
  const user = tg.initDataUnsafe?.user;
  const firstName = user?.first_name || "";
  const telegramPhotoUrl = user?.photo_url;

  const storageKey = "growthhub_visited";
  const isFirstVisit = !localStorage.getItem(storageKey);
  const welcomeEl = document.getElementById("homeWelcomeText");
  const nameEl = document.getElementById("homeUserName");

  if (isFirstVisit) {
    welcomeEl.textContent = "Hello there";
    nameEl.textContent = firstName || "";
    localStorage.setItem(storageKey, "1");
  } else {
    welcomeEl.textContent = "Welcome back";
    nameEl.textContent = firstName || "there";
  }

  const [categories, top, recent, featured, myProfile] = await Promise.all([
    asArray(await apiGet("/api/categories")),
    asArray(await apiGet("/api/top?limit=10")),
    asArray(await apiGet("/api/recent?limit=10")),
    asArray(await apiGet("/api/featured?limit=10")),
    apiGet("/api/profile"),
  ]);

  // The welcome banner used to show the person's Telegram account photo
  // (photo_url from initDataUnsafe) — but that's not "the picture the
  // user uploaded" to GrowthHub, it's whatever their Telegram profile
  // picture happens to be, which may not even exist or may be totally
  // unrelated. Prefer the photo they actually uploaded to their listing;
  // fall back to their Telegram photo only if they haven't registered
  // or haven't uploaded one yet, and to a plain icon after that.
  const avatarEl = document.getElementById("homeAvatar");
  if (myProfile && !myProfile.error && myProfile.id && (myProfile.photo_base64 || myProfile.photo_file_id)) {
    avatarEl.innerHTML = `<img src="${photoUrl(myProfile.id)}" alt="" data-avatar-img>`;
    const img = avatarEl.querySelector("[data-avatar-img]");
    img.addEventListener("error", () => { avatarEl.innerHTML = noPhotoIconHtml(); }, { once: true });
  } else if (telegramPhotoUrl) {
    avatarEl.innerHTML = `<img src="${escapeHtml(telegramPhotoUrl)}" alt="" data-avatar-img>`;
    const img = avatarEl.querySelector("[data-avatar-img]");
    img.addEventListener("error", () => { avatarEl.innerHTML = noPhotoIconHtml(); }, { once: true });
  } else {
    avatarEl.innerHTML = noPhotoIconHtml();
  }

  // Categories — hand-drawn outline icon (matching the mockup you
  // approved) instead of emoji, which rendered small and inconsistently
  // across devices in Telegram's in-app browser.
  const chipContainer = document.getElementById("homeCategoryChips");
  chipContainer.innerHTML = categories.slice(0, 10).map(c => `
    <button class="category-chip" data-category="${escapeHtml(c.name)}">
      <span class="category-chip-icon">${categoryIconHtml(c.name)}</span>
      <span>${escapeHtml(c.name)}</span>
    </button>`).join("");
  chipContainer.querySelectorAll(".category-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      showView("explore");
      setTimeout(() => {
        document.getElementById("searchInput").value = chip.dataset.category;
        runSearch(chip.dataset.category);
      }, 50);
    });
  });

  // Top
  renderCardScroll("homeTop", top);

  // Recent
  renderCardScroll("homeRecent", recent);

  // Trending (use top as proxy)
  if (top.length > 3) {
    document.getElementById("homeTrendingBlock").style.display = "block";
    renderCardScroll("homeTrending", top.slice(0, 8));
  }

  // Featured
  if (featured.length > 0) {
    document.getElementById("homeFeaturedBlock").style.display = "block";
    renderCardScroll("homeFeatured", featured);
  }
}

function renderCardScroll(containerId, items) {
  const container = document.getElementById(containerId);
  if (!items.length) {
    container.innerHTML = `<div class="empty-state" style="min-width:200px;"><p>No entrepreneurs yet.</p></div>`;
    return;
  }
  container.innerHTML = items.map(item => {
    const ratingText = item.avg_rating ? `\u2b50 ${item.avg_rating}` : "";
    const rawService = (item.services && item.services[0]) || "";
    const serviceLabel = typeof rawService === "object" ? rawService.name : rawService;
    return `
      <div class="business-card" data-open-id="${item.id}">
        <div class="card-avatar" style="background:${colorForName(item.name)}" data-avatar-for="${item.id}">
          ${item.id && (item.photo_base64 || item.photo_file_id)
            ? `<img src="${photoUrl(item.id)}" alt="" data-avatar-img>`
            : noPhotoIconHtml()}
        </div>
        <div class="card-name">${escapeHtml(item.name)}</div>
        <div class="card-service">${escapeHtml(serviceLabel)}</div>
        <div class="card-rating">${ratingText}</div>
      </div>`;
  }).join("");
  // Attached in JS rather than an inline onerror="..." attribute — the
  // fallback icon's own SVG markup uses double quotes, which would
  // prematurely terminate a double-quoted onerror HTML attribute and
  // corrupt the markup. This sidesteps that entirely.
  container.querySelectorAll("[data-avatar-img]").forEach(img => {
    img.addEventListener("error", () => { img.parentElement.innerHTML = noPhotoIconHtml(); }, { once: true });
  });
  container.querySelectorAll("[data-open-id]").forEach(card => {
    card.style.cursor = "pointer";
    card.addEventListener("click", () => openDetail(card.dataset.openId));
    // NOTE: entrepreneur ids are Mongo ObjectId strings (24 hex chars),
    // not numbers — Number("507f...") is NaN, which silently sent every
    // click here to /api/entrepreneur/NaN and rendered "listing not found".
  });
}

// ============================================================
// EXPLORE
// ============================================================
let exploreServicesCache = [];
let exploreActiveType = "all";

async function loadExplore() {
  if (!exploreServicesCache.length) {
    exploreServicesCache = asArray(await apiGet("/api/services"));
  }
  renderExploreChips();
  setupExploreTypeTabs();
}

function renderExploreChips() {
  const chipContainer = document.getElementById("exploreChips");
  const filtered = exploreActiveType === "all"
    ? exploreServicesCache
    : exploreServicesCache.filter(s => (s.type || "service") === exploreActiveType);

  chipContainer.innerHTML =
    `<button class="chip active" data-chip="all">All</button>` +
    filtered.slice(0, 12).map(s => `<button class="chip" data-chip="${escapeHtml(s.name)}">${escapeHtml(s.name)}</button>`).join("");

  chipContainer.querySelectorAll(".chip").forEach(chip => {
    chip.addEventListener("click", () => {
      chipContainer.querySelectorAll(".chip").forEach(c => c.classList.remove("active"));
      chip.classList.add("active");
      const value = chip.dataset.chip === "all" ? "" : chip.dataset.chip;
      document.getElementById("searchInput").value = value;
      runSearch(value);
    });
  });
}

function setupExploreTypeTabs() {
  document.querySelectorAll(".explore-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".explore-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      exploreActiveType = tab.dataset.type;
      renderExploreChips();
      const q = document.getElementById("searchInput").value.trim();
      if (q) runSearch(q);
    });
  });
}

let searchOffset = 0;
const SEARCH_LIMIT = 20;
let searchTotal = 0;
let searchQuery = "";

async function runSearch(query, append = false) {
  const container = document.getElementById("exploreResults");
  if (!query) {
    container.innerHTML = "";
    return;
  }
  if (!append) {
    searchOffset = 0;
    searchQuery = query;
    container.innerHTML = "";
  }
  const typeParam = exploreActiveType !== "all" ? `&type=${exploreActiveType}` : "";
  const locParam = (userLat && userLng) ? `&lat=${userLat}&lng=${userLng}` : "";
  const data = await apiGet(`/api/find?service=${encodeURIComponent(searchQuery)}${typeParam}${locParam}&limit=${SEARCH_LIMIT}&offset=${searchOffset}`);
  const results = asArray(data?.results || data);
  searchTotal = data?.total || results.length;
  searchOffset += results.length;

  if (!append) container.innerHTML = "";
  if (results.length) {
    container.insertAdjacentHTML("beforeend", results.map(r => renderResultCard(r)).join(""));
    wireResultCardClicks(container);
  }
  const existingBtn = container.querySelector(".load-more-btn");
  if (existingBtn) existingBtn.remove();
  if (searchOffset < searchTotal) {
    const btn = document.createElement("button");
    btn.className = "load-more-btn";
    btn.textContent = `Load More (${searchOffset}/${searchTotal})`;
    btn.onclick = () => runSearch(searchQuery, true);
    container.appendChild(btn);
  } else if (searchOffset > 0) {
    container.insertAdjacentHTML("beforeend", `<p class="search-count">${searchTotal} result${searchTotal !== 1 ? "s" : ""}</p>`);
  }
}

function renderResultCard(r) {
  const ratingText = r.avg_rating ? `\u2b50 ${r.avg_rating} (${r.rating_count})` : "No ratings yet";
  const rawService = (r.services && r.services[0]) || "";
  const serviceLabel = typeof rawService === "object" ? rawService.name : rawService;
  const distText = (r.distance_km != null && userLat && userLng)
    ? `<span class="distance-text">${r.distance_km < 1 ? Math.round(r.distance_km * 1000) + "m" : r.distance_km.toFixed(1) + "km"} away</span>`
    : "";
  const verifiedBadge = r.identity_verified
    ? `<span class="verified-badge-inline" title="Verified"><svg width="14" height="14" viewBox="0 0 24 24" fill="#0F9B8E"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span>`
    : "";
  return `
    <div class="result-card" data-open-id="${r.id}">
      ${avatarHtml(r)}
      <div class="result-info">
        <h3>${escapeHtml(r.name)}${verifiedBadge}</h3>
        <p class="result-service">${escapeHtml(serviceLabel)}</p>
        <p class="result-rating">${ratingText}${distText}</p>
      </div>
    </div>`;
}

function wireResultCardClicks(container) {
  container.querySelectorAll("[data-open-id]").forEach(card => {
    card.style.cursor = "pointer";
    card.addEventListener("click", () => openDetail(card.dataset.openId));
    // NOTE: entrepreneur ids are Mongo ObjectId strings (24 hex chars),
    // not numbers — Number("507f...") is NaN, which silently sent every
    // click here to /api/entrepreneur/NaN and rendered "listing not found".
  });
}

document.getElementById("searchInput").addEventListener("input", (e) => {
  const q = e.target.value.trim();
  document.querySelectorAll("#exploreChips .chip").forEach(c => c.classList.remove("active"));
  if (q.length > 1) runSearch(q);
  else document.getElementById("exploreResults").innerHTML = "";
});

// ============================================================
// FAVORITES
// ============================================================
async function loadFavorites() {
  const container = document.getElementById("favoritesContent");
  const favorites = asArray(await apiGet("/api/favorites"));
  if (!favorites.length) {
    container.innerHTML = `
      <div class="favorites-empty">
        <svg viewBox="0 0 24 24" fill="none"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" stroke="currentColor" stroke-width="2"/></svg>
        <p>No favorites yet.<br>Tap the heart icon on any profile to save it here.</p>
      </div>`;
    return;
  }
  container.innerHTML = `<div class="results">${favorites.map(r => `
    <div class="result-card" data-open-id="${r.id}">
      ${avatarHtml(r)}
      <div class="result-info">
        <h3>${escapeHtml(r.name)}</h3>
        <p class="result-service">${escapeHtml((r.services && r.services[0]) || "")}</p>
        <p class="result-rating">${r.avg_rating ? `\u2b50 ${r.avg_rating} (${r.rating_count})` : "No ratings yet"}</p>
      </div>
      <button class="fav-remove-btn" data-fav-remove="${r.id}" title="Remove from favorites">
        <svg viewBox="0 0 24 24" fill="none" style="width:16px;height:16px;"><path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
      </button>
    </div>`).join("")}</div>`;
  wireResultCardClicks(container);
  container.querySelectorAll("[data-fav-remove]").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const id = btn.dataset.favRemove; // ObjectId string, not a number — same fix as openDetail() above
      await apiPost("/api/favorites/remove", { initData: tg.initData, entrepreneur_id: id });
      loadFavorites();
    });
  });
}

// ============================================================
// PROFILE
// ============================================================
let currentProfile = null;

async function loadProfile() {
  const container = document.getElementById("profileContent");
  const profile = await apiGet("/api/profile");

  if (profile && profile.error === "invalid_init_data") {
    container.innerHTML = emptyState("Couldn't verify your account. Try reopening from the bot.");
    return;
  }
  currentProfile = profile;

  if (!profile) {
    container.innerHTML = `
      <div class="profile-cta">
        <div class="avatar-circle" style="background:var(--secondary);width:60px;height:60px;margin:0 auto 12px;">
          <svg viewBox="0 0 24 24" fill="none" style="width:26px;height:26px;"><path d="M12 5v14M5 12h14" stroke="white" stroke-width="2.4" stroke-linecap="round"/></svg>
        </div>
        <h3>You're not listed yet</h3>
        <p>Create your listing so people can discover your services and products.</p>
        <button class="btn-primary" id="registerCta">Get Started</button>
      </div>`;
    document.getElementById("registerCta").addEventListener("click", () => openStepper(null));
    return;
  }

  const ratingText = profile.avg_rating ? `\u2b50 ${profile.avg_rating} (${profile.rating_count} reviews)` : "No ratings yet";
  const memberSince = profile.created_at ? profile.created_at.slice(0, 4) : "\u2014";
  const servicesList = (profile.services || []).map(s => typeof s === "object" ? s.name : s).join(", ");
  const isFreelancerProfile = profile.user_type === "freelancer";

  if (isFreelancerProfile) {
    container.innerHTML = `
      <div class="profile-hero">
        ${avatarHtml(profile, 76)}
        <h2>${escapeHtml(profile.name)}</h2>
        <p class="tagline">${escapeHtml(servicesList) || "No services yet"}</p>
        <p class="rating-line">${ratingText}</p>
        <div class="stat-row">
          <div class="stat"><b>${(profile.services || []).length}</b><span>Services</span></div>
          <div class="stat"><b>${profile.rating_count}</b><span>Reviews</span></div>
          <div class="stat"><b>${memberSince}</b><span>Member</span></div>
        </div>
      </div>
      ${profile.description ? `<div class="detail-section"><div class="detail-section-title">About</div><p style="font-size:14px;color:var(--text-muted);line-height:1.6;margin:0;">${escapeHtml(profile.description)}</p></div>` : ""}
      ${renderSocialPlatformsDisplay(profile)}
      <div class="detail-section">
        <div class="detail-section-title">Contact</div>
        <div class="detail-list">
          <div class="detail-row"><span class="label">Phone</span><span class="value">${escapeHtml(profile.phone) || "\u2014"}</span>${profile.phone ? `<button class="copy-icon" data-copy="${escapeHtml(profile.phone)}" aria-label="Copy phone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
          <div class="detail-row"><span class="label">Email</span><span class="value">${escapeHtml(profile.email) || "\u2014"}</span>${profile.email ? `<button class="copy-icon" data-copy="${escapeHtml(profile.email)}" aria-label="Copy email"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
          <div class="detail-row"><span class="label">Business address</span><span class="value">${escapeHtml(profile.business_address) || "\u2014"}</span></div>
          <div class="detail-row"><span class="label">Website</span><span class="value">${escapeHtml(profile.website) || "\u2014"}</span></div>
          <div class="detail-row"><span class="label">Home address<span class="private-badge">Private</span></span><span class="value">${escapeHtml(profile.home_address) || "\u2014"}</span></div>
        </div>
      </div>
      <div class="menu-list">
        <div class="menu-item" id="editListingBtn">Edit My Listing<span class="chevron">\u203a</span></div>
        <div class="menu-item danger" id="removeListingBtn">Remove My Listing<span class="chevron">\u203a</span></div>
      </div>`;

    document.getElementById("editListingBtn").addEventListener("click", () => openStepper(profile));
    document.getElementById("removeListingBtn").addEventListener("click", () => {
      safeConfirm("Remove your listing? This can't be undone.", async (confirmed) => {
        if (!confirmed) return;
        await apiPost("/api/unregister", { initData: tg.initData });
        verifiedPhoneNumber = null;
        currentUserType = null;
        safeAlert("You've been removed from the list.");
        loadProfile();
      });
    });
  } else {
    container.innerHTML = `
      <div class="profile-hero">
        ${avatarHtml(profile, 76)}
        <h2>${escapeHtml(profile.name)}</h2>
        <p class="tagline">Member since ${memberSince}</p>
        <div class="stat-row">
          <div class="stat"><b>${profile.reviews_written || 0}</b><span>Reviews</span></div>
          <div class="stat"><b>${profile.favorites_count || 0}</b><span>Favorites</span></div>
          <div class="stat"><b>${memberSince}</b><span>Member</span></div>
        </div>
      </div>
      <div class="detail-section">
        <div class="detail-section-title">Contact</div>
        <div class="detail-list">
          <div class="detail-row"><span class="label">Phone</span><span class="value">${escapeHtml(profile.phone) || "\u2014"}</span>${profile.phone ? `<button class="copy-icon" data-copy="${escapeHtml(profile.phone)}" aria-label="Copy phone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
          <div class="detail-row"><span class="label">Email</span><span class="value">${escapeHtml(profile.email) || "\u2014"}</span>${profile.email ? `<button class="copy-icon" data-copy="${escapeHtml(profile.email)}" aria-label="Copy email"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
        </div>
      </div>
      <div class="menu-list">
        <div class="menu-item" id="upgradeToFreelancerBtn" style="color:var(--secondary);font-weight:600;">Become a Freelancer<span class="chevron">\u203a</span></div>
        <div class="menu-item danger" id="removeListingBtn">Remove Account<span class="chevron">\u203a</span></div>
      </div>`;

    document.getElementById("upgradeToFreelancerBtn").addEventListener("click", async () => {
      safeConfirm("Upgrade to a freelancer? You'll be able to list services and get discovered.", async (confirmed) => {
        if (!confirmed) return;
        const { ok } = await apiPost("/api/upgrade_to_freelancer", { initData: tg.initData });
        if (ok) {
          currentUserType = "freelancer";
          safeAlert("Upgraded! Now set up your services.");
          loadProfile();
        }
      });
    });
    document.getElementById("removeListingBtn").addEventListener("click", () => {
      safeConfirm("Remove your account? This can't be undone.", async (confirmed) => {
        if (!confirmed) return;
        await apiPost("/api/unregister", { initData: tg.initData });
        verifiedPhoneNumber = null;
        currentUserType = null;
        safeAlert("You've been removed.");
        openStepper(null);
      });
    });
  }
}

// ============================================================
// ENTREPRENEUR DETAIL
// ============================================================
let detailReturnView = "explore";
let detailEntrepreneurId = null;
let detailIsFavorited = false;

async function openDetail(entrepreneurId) {
  const activeView = document.querySelector(".view.active");
  if (activeView && activeView.id !== "view-detail") {
    detailReturnView = activeView.id.replace("view-", "");
  }
  detailEntrepreneurId = entrepreneurId;

  showView("detail");
  const container = document.getElementById("detailContent");
  container.innerHTML = `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">Loading...</p>`;

  const profile = await apiGet(`/api/entrepreneur/${entrepreneurId}`);
  if (profile.error) {
    container.innerHTML = emptyState("This listing couldn't be found.");
    return;
  }
  const reviews = asArray(await apiGet(`/api/reviews/${entrepreneurId}`));
  detailIsFavorited = profile.is_favorited || false;

  // Update fav button
  const favBtn = document.getElementById("detailFavBtn");
  favBtn.style.display = profile.is_owner ? "none" : "flex";
  updateFavButton();

  const ratingText = profile.avg_rating ? `\u2b50 ${profile.avg_rating} (${profile.rating_count} reviews)` : "No ratings yet";
  const servicesList = (profile.services || []).map(s => typeof s === "object" ? s.name : s).join(", ");
  const verifiedBadge = profile.identity_verified
    ? `<span class="verified-badge-inline" title="Verified" style="margin-left:6px;"><svg width="18" height="18" viewBox="0 0 24 24" fill="#0F9B8E"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span>`
    : "";

  // Gallery
  let galleryHtml = "";
  if (profile.gallery && profile.gallery.length > 0) {
    galleryHtml = `
      <div class="detail-section">
        <div class="detail-section-title">Gallery</div>
        <div class="gallery-grid">${profile.gallery.map(img => `<img src="data:image/jpeg;base64,${img}" />`).join("")}</div>
      </div>`;
  }

  // Services/Products
  let servicesHtml = "";
  if (profile.services && profile.services.length > 0) {
    servicesHtml = `
      <div class="detail-section">
        <div class="detail-section-title">Services & Products</div>
        <div class="services-list">${profile.services.map(s => {
          const name = typeof s === "object" ? s.name : s;
          const desc = typeof s === "object" ? s.description : "";
          const price = typeof s === "object" ? s.price : 0;
          return `
            <div class="service-item">
              <div class="service-item-info">
                <div class="service-item-name">${escapeHtml(name)}</div>
                ${desc ? `<div class="service-item-desc">${escapeHtml(desc)}</div>` : ""}
              </div>
              ${price > 0 ? `<div class="service-item-price">\u20a6${Number(price).toLocaleString()}</div>` : ""}
            </div>`;
        }).join("")}</div>
      </div>`;
  }

  // Reviews
  let reviewsHtml = reviews.length
    ? reviews.map(rev => `
      <div class="review-card">
        <div class="review-head">
          <b>${escapeHtml(rev.rater_name || "Anonymous")}</b>
          <span class="review-stars">${"\u2605".repeat(rev.score)}${"\u2606".repeat(5 - rev.score)}</span>
        </div>
        ${rev.comment ? `<p class="review-comment">${escapeHtml(rev.comment)}</p>` : ""}
        ${rev.created_at ? `<div class="review-date">${escapeHtml(rev.created_at.slice(0, 10))}</div>` : ""}
      </div>`).join("")
    : `<p class="field-hint">${profile.is_owner ? "No reviews yet." : `No reviews yet \u2014 be the first to rate ${escapeHtml(profile.name)}.`}</p>`;

  container.innerHTML = `
    <div class="profile-hero">
      ${avatarHtml(profile, 76)}
      <h2>${escapeHtml(profile.name)}${verifiedBadge}</h2>
      <p class="tagline">${escapeHtml(servicesList) || ""}</p>
      <p class="rating-line">${ratingText}</p>
    </div>
    ${profile.description ? `<div class="detail-section"><div class="detail-section-title">About</div><p style="font-size:14px;color:var(--text-muted);line-height:1.6;margin:0;">${escapeHtml(profile.description)}</p></div>` : ""}
    ${servicesHtml}
    ${galleryHtml}
    ${renderSocialPlatformsDisplay(profile)}
    <div class="detail-section">
      <div class="detail-section-title">Contact</div>
      <div class="detail-list">
        <div class="detail-row"><span class="label">Phone</span><span class="value">${escapeHtml(profile.phone) || "\u2014"}</span>${profile.phone ? `<button class="copy-icon" data-copy="${escapeHtml(profile.phone)}" aria-label="Copy phone"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
        <div class="detail-row"><span class="label">Email</span><span class="value">${escapeHtml(profile.email) || "\u2014"}</span>${profile.email ? `<button class="copy-icon" data-copy="${escapeHtml(profile.email)}" aria-label="Copy email"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>` : ""}</div>
        <div class="detail-row"><span class="label">Business address</span><span class="value">${escapeHtml(profile.business_address) || "\u2014"}</span></div>
        <div class="detail-row"><span class="label">Website</span><span class="value">${escapeHtml(profile.website) || "\u2014"}</span></div>
      </div>
    </div>
    ${profile.telegram_username && !profile.is_owner ? `<button class="btn-telegram" data-telegram-username="${escapeHtml(profile.telegram_username)}"><svg width="18" height="18" viewBox="0 0 24 24" fill="#0088cc"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg> Contact on Telegram</button>` : ""}
    ${profile.is_owner ? "" : `<button class="btn-primary" id="detailRateBtn" style="margin-top:10px;">Rate ${escapeHtml(profile.name)}</button>`}
    <div class="detail-section" style="margin-top:22px;">
      <div class="detail-section-title">Reviews</div>
      <div class="reviews-list">${reviewsHtml}</div>
    </div>`;

  const rateBtn = document.getElementById("detailRateBtn");
  if (rateBtn) rateBtn.addEventListener("click", () => openRatingModal(entrepreneurId, profile.name));

  // tg.openTelegramLink() instead of a plain <a href="https://t.me/...">
  // — a normal link fully closes the mini app when Telegram's webview
  // intercepts it. openTelegramLink is Telegram's own method for this
  // exact handoff and, since Bot API 7.0, no longer closes the mini app
  // when called (it used to, on older Bot API versions). Leaving to an
  // actual different chat is inherent to "contact via Telegram DM" —
  // this only smooths the transition, it can't avoid it entirely.
  const telegramBtn = document.querySelector("[data-telegram-username]");
  if (telegramBtn) {
    telegramBtn.addEventListener("click", () => {
      const username = telegramBtn.dataset.telegramUsername;
      if (tg.openTelegramLink) {
        tg.openTelegramLink(`https://t.me/${username}`);
      } else {
        window.open(`https://t.me/${username}`, "_blank");
      }
    });
  }
}

function updateFavButton() {
  const favBtn = document.getElementById("detailFavBtn");
  if (detailIsFavorited) {
    favBtn.classList.add("fav-active");
    favBtn.querySelector("svg").setAttribute("fill", "currentColor");
  } else {
    favBtn.classList.remove("fav-active");
    favBtn.querySelector("svg").setAttribute("fill", "none");
  }
}

document.getElementById("detailFavBtn").addEventListener("click", async () => {
  if (!detailEntrepreneurId) return;
  if (detailIsFavorited) {
    await apiPost("/api/favorites/remove", { initData: tg.initData, entrepreneur_id: detailEntrepreneurId });
    detailIsFavorited = false;
  } else {
    await apiPost("/api/favorites/add", { initData: tg.initData, entrepreneur_id: detailEntrepreneurId });
    detailIsFavorited = true;
  }
  updateFavButton();
});

// ---- Rating Modal ----
function openRatingModal(entrepreneurId, name) {
  let selectedScore = 0;
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-card">
      <h3>Rate ${escapeHtml(name)}</h3>
      <p class="field-hint">Tap a star, then add a comment if you'd like.</p>
      <div class="star-row">
        ${[1,2,3,4,5].map(n => `<button class="star-btn" data-score="${n}">\u2605</button>`).join("")}
      </div>
      <textarea id="ratingComment" rows="3" placeholder="Optional — share your experience"></textarea>
      <button class="btn-primary" id="ratingSubmitBtn">Submit Rating</button>
      <button class="btn-secondary btn-modal-cancel" id="ratingCancelBtn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  const starButtons = overlay.querySelectorAll(".star-btn");
  starButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      selectedScore = Number(btn.dataset.score);
      starButtons.forEach(b => b.classList.toggle("selected", Number(b.dataset.score) <= selectedScore));
    });
  });

  document.getElementById("ratingSubmitBtn").addEventListener("click", async () => {
    if (!selectedScore) {
      tg.showAlert ? tg.showAlert("Please tap a star first.") : alert("Please tap a star first.");
      return;
    }
    const comment = document.getElementById("ratingComment").value.trim();
    overlay.remove();
    const { ok } = await apiPost("/api/rate", { initData: tg.initData, entrepreneur_id: entrepreneurId, score: selectedScore, comment });
    tg.showAlert ? tg.showAlert(ok ? "Thanks for rating!" : "Something went wrong.") : alert(ok ? "Thanks!" : "Error.");
    if (ok) openDetail(entrepreneurId);
  });

  document.getElementById("ratingCancelBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

document.getElementById("detailBack").addEventListener("click", () => showView(detailReturnView));

// ============================================================
// STEPPER (6 steps)
// ============================================================
let stepperTags = [];
let currentStep = 1;
let uploadedPhotoBase64 = null;
let verifiedPhoneNumber = null;
let phonePollTimer = null;
let selectedOfferType = "service";
let selectedUserRole = null;
let isFreelancer = false;

const SOCIAL_PLATFORMS = [
  { id: "instagram", label: "Instagram", placeholder: "@username",
    svg: `<svg viewBox="0 0 24 24" fill="#E4405F"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>` },
  { id: "twitter", label: "X", placeholder: "@username",
    svg: `<svg viewBox="0 0 24 24" fill="#000000"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>` },
  { id: "facebook", label: "Facebook", placeholder: "facebook.com/username",
    svg: `<svg viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>` },
  { id: "linkedin", label: "LinkedIn", placeholder: "linkedin.com/in/username",
    svg: `<svg viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>` },
  { id: "youtube", label: "YouTube", placeholder: "@channel",
    svg: `<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>` },
];

let socialPlatforms = [];

function renderSocialPlatforms() {
  const container = document.getElementById("socialPlatformsList");
  if (!container) return;
  container.innerHTML = socialPlatforms.map((sp, i) => {
    const platDef = SOCIAL_PLATFORMS.find(p => p.id === sp.platform) || SOCIAL_PLATFORMS[0];
    return `
      <div class="social-platform-row" data-index="${i}">
        <div class="social-platform-select-wrap">
          <select class="social-platform-select" data-index="${i}">
            ${SOCIAL_PLATFORMS.map(p => `<option value="${p.id}" ${p.id === sp.platform ? "selected" : ""}>${p.label}</option>`).join("")}
          </select>
          <svg class="social-platform-arrow" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </div>
        <input type="text" class="social-platform-handle" data-index="${i}"
               placeholder="${escapeHtml(platDef.placeholder)}"
               value="${escapeHtml(sp.handle)}" />
        <button type="button" class="social-platform-remove" data-index="${i}">&times;</button>
      </div>`;
  }).join("");

  container.querySelectorAll(".social-platform-select").forEach(sel => {
    sel.addEventListener("change", (e) => {
      const idx = Number(e.target.dataset.index);
      socialPlatforms[idx].platform = e.target.value;
      const platDef = SOCIAL_PLATFORMS.find(p => p.id === e.target.value);
      const handleInput = container.querySelector(`.social-platform-handle[data-index="${idx}"]`);
      if (handleInput && platDef) handleInput.placeholder = platDef.placeholder;
    });
  });
  container.querySelectorAll(".social-platform-handle").forEach(input => {
    input.addEventListener("input", (e) => {
      socialPlatforms[Number(e.target.dataset.index)].handle = e.target.value;
    });
  });
  container.querySelectorAll(".social-platform-remove").forEach(btn => {
    btn.addEventListener("click", () => {
      socialPlatforms.splice(Number(btn.dataset.index), 1);
      renderSocialPlatforms();
    });
  });
}

function addSocialPlatform() {
  if (socialPlatforms.length >= 9) {
    tg.showAlert?.("Maximum 9 social accounts.");
    return;
  }
  const usedPlatforms = socialPlatforms.map(sp => sp.platform);
  const nextPlat = SOCIAL_PLATFORMS.find(p => !usedPlatforms.includes(p.id)) || SOCIAL_PLATFORMS[0];
  socialPlatforms.push({ platform: nextPlat.id, handle: "" });
  renderSocialPlatforms();
  const handles = document.querySelectorAll(".social-platform-handle");
  if (handles.length) handles[handles.length - 1].focus();
}

function openStepper(existingProfile) {
  currentStep = 1;
  stepperTags = existingProfile ? [...(existingProfile.services || []).map(s => typeof s === "object" ? s.name : s)] : [];
  uploadedPhotoBase64 = null;
  verifiedPhoneNumber = existingProfile?.phone_verified ? existingProfile.phone : null;
  selectedOfferType = existingProfile?.business_type || "service";
  selectedUserRole = existingProfile?.user_type || null;
  isFreelancer = selectedUserRole === "freelancer";

  document.getElementById("stepName").value = existingProfile?.name || (tg.initDataUnsafe?.user ? [tg.initDataUnsafe.user.first_name, tg.initDataUnsafe.user.last_name].filter(Boolean).join(" ") : "");
  document.getElementById("stepEmail").value = existingProfile?.email || "";
  document.getElementById("stepBusinessAddress").value = existingProfile?.business_address || "";
  document.getElementById("stepWebsite").value = existingProfile?.website || "";
  document.getElementById("stepHomeAddress").value = existingProfile?.home_address || "";
  document.getElementById("stepDescription").value = existingProfile?.description || "";

  socialPlatforms = [];
  if (existingProfile?.social_platforms) {
    try {
      const parsed = typeof existingProfile.social_platforms === "string"
        ? JSON.parse(existingProfile.social_platforms) : existingProfile.social_platforms;
      // Defensive filter: older saves (before social platforms were
      // consistently stored as { platform, handle } objects) may have
      // left plain strings behind. A string here has no .handle, which
      // would throw at submit time (see the filter() below) — dropping
      // anything that isn't a proper {platform, handle} object means an
      // account with old data can still edit and re-save cleanly instead
      // of being stuck on a crash it has no way to fix from the UI.
      if (Array.isArray(parsed)) {
        socialPlatforms = parsed.filter(sp => sp && typeof sp === "object" && typeof sp.platform === "string");
      }
    } catch(e) {}
  }
  renderSocialPlatforms();

  refreshPhoneVerifiedUI();
  checkPhoneVerification();

  document.getElementById("photoPreviewImg").style.display = "none";
  document.getElementById("photoPlaceholderIcon").style.display = "block";
  document.getElementById("photoUploadLabel").textContent = "Upload a photo";

  if (existingProfile?.id && (existingProfile.photo_base64 || existingProfile.photo_file_id)) {
    document.getElementById("photoPreviewImg").src = photoUrl(existingProfile.id);
    document.getElementById("photoPreviewImg").style.display = "block";
    document.getElementById("photoPlaceholderIcon").style.display = "none";
    document.getElementById("photoUploadLabel").textContent = "Tap to change";
  }

  document.getElementById("stepperTitle").textContent = existingProfile ? "Edit Listing" : "Register";

  document.querySelectorAll(".offer-type-card").forEach(c => c.classList.remove("selected"));
  const selectedCard = document.querySelector(`.offer-type-card[data-offer="${selectedOfferType}"]`);
  if (selectedCard) selectedCard.classList.add("selected");

  document.querySelectorAll(".offer-type-card[data-role]").forEach(c => c.classList.remove("selected"));
  if (selectedUserRole) {
    const roleCard = document.querySelector(`.offer-type-card[data-role="${selectedUserRole}"]`);
    if (roleCard) roleCard.classList.add("selected");
  }

  renderTags();
  goToStep(1);
  showView("stepper");
}

function renderTags() {
  const container = document.getElementById("serviceTags");
  container.innerHTML = stepperTags.map((t, i) => `<span class="tag-pill">${escapeHtml(t)}<button data-remove="${i}">\u00d7</button></span>`).join("");
  container.querySelectorAll("[data-remove]").forEach(btn => {
    btn.addEventListener("click", () => {
      stepperTags.splice(Number(btn.dataset.remove), 1);
      renderTags();
    });
  });
}

// ---- Phone verification ----
function refreshPhoneVerifiedUI(state) {
  if (!state) state = verifiedPhoneNumber ? "verified" : "idle";
  const display = document.getElementById("phoneVerifiedDisplay");
  const waiting = document.getElementById("phoneWaitingState");
  const btn = document.getElementById("verifyPhoneBtn");
  const numberSpan = document.getElementById("phoneVerifiedNumber");
  const hint = document.getElementById("verifyPhoneHint");

  display.style.display = state === "verified" ? "flex" : "none";
  waiting.style.display = state === "waiting" ? "flex" : "none";
  btn.style.display = state === "idle" ? "block" : "none";

  if (state === "verified") {
    numberSpan.textContent = verifiedPhoneNumber;
    hint.textContent = "You're all set.";
  } else if (state === "waiting") {
    hint.textContent = "";
  } else {
    hint.textContent = "Tap the button and approve the prompt. No other steps needed.";
  }
}

async function checkPhoneVerification() {
  const { verified, phone } = await apiGet("/api/check_phone");
  if (verified) {
    verifiedPhoneNumber = phone;
    refreshPhoneVerifiedUI("verified");
    if (phonePollTimer) { clearInterval(phonePollTimer); phonePollTimer = null; }
  }
  return verified;
}

document.getElementById("verifyPhoneBtn").addEventListener("click", () => {
  if (typeof tg.requestContact !== "function") {
    tg.showAlert?.("Please update Telegram to register.");
    return;
  }
  tg.requestContact((shared) => {
    if (!shared) return;
    refreshPhoneVerifiedUI("waiting");
    if (phonePollTimer) clearInterval(phonePollTimer);
    let attempts = 0;
    phonePollTimer = setInterval(async () => {
      attempts++;
      const ok = await checkPhoneVerification();
      if (ok || attempts > 15) {
        clearInterval(phonePollTimer);
        phonePollTimer = null;
        if (!ok) {
          refreshPhoneVerifiedUI("idle");
          document.getElementById("verifyPhoneHint").textContent = "Still waiting \u2014 check your bot chat, then try again.";
        }
      }
    }, 2000);
  });
});

document.getElementById("serviceEntry").addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === ",") {
    e.preventDefault();
    const value = e.target.value.trim().replace(/,$/, "");
    if (value) { stepperTags.push(value); renderTags(); }
    e.target.value = "";
  }
});

// ---- Photo uploads ----
function setupPhotoUpload(zoneId, inputId, previewImgId, placeholderId, labelId, stateKey) {
  document.getElementById(zoneId).addEventListener("click", () => document.getElementById(inputId).click());
  document.getElementById(inputId).addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const MAX_WIDTH = 640;
        const scale = Math.min(1, MAX_WIDTH / img.width);
        const canvas = document.createElement("canvas");
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL("image/jpeg", 0.75);
        if (stateKey === "photo") uploadedPhotoBase64 = base64;
        document.getElementById(previewImgId).src = base64;
        document.getElementById(previewImgId).style.display = "block";
        document.getElementById(placeholderId).style.display = "none";
        document.getElementById(labelId).textContent = "Tap to change";
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  });
}
setupPhotoUpload("photoUploadZone", "photoInput", "photoPreviewImg", "photoPlaceholderIcon", "photoUploadLabel", "photo");


// Social platforms: add button
document.getElementById("addSocialPlatformBtn").addEventListener("click", addSocialPlatform);

function getStepMapping() {
  if (isFreelancer) {
    return { panels: [1, 2, 3, 4, 5, 6, 7], totalSteps: 7, submitAfter: 7 };
  }
  return { panels: [1, 3, 6], totalSteps: 3, submitAfter: 3 };
}

function goToStep(step) {
  currentStep = step;
  const mapping = getStepMapping();
  const panelId = mapping.panels[step - 1];

  document.querySelectorAll(".step-panel").forEach(p => p.classList.remove("active"));
  const panel = document.querySelector(`.step-panel[data-step-panel="${panelId}"]`);
  if (panel) panel.classList.add("active");

  const progress = ((step - 1) / (mapping.totalSteps - 1)) * 100;
  document.getElementById("progressFill").style.width = `${progress}%`;
  document.getElementById("stepLabel").textContent = `Step ${step} of ${mapping.totalSteps}`;
  document.getElementById("stepBackBtn").style.visibility = step === 1 ? "hidden" : "visible";
  document.getElementById("stepNextBtn").textContent = step === mapping.totalSteps ? "Submit" : "Next";

  if (panelId === 4) {
    const title = document.getElementById("step3Title");
    const productFields = document.getElementById("productFields");
    if (selectedOfferType === "product") {
      title.innerHTML = 'Your Products <span class="req">*required</span>';
      productFields.style.display = "block";
    } else if (selectedOfferType === "both") {
      title.innerHTML = 'Your Services & Products <span class="req">*required</span>';
      productFields.style.display = "block";
    } else {
      title.innerHTML = 'Your Services <span class="req">*required</span>';
      productFields.style.display = "none";
    }
  }

  if (panelId === 7) {
    const hasBusinessAddress = document.getElementById("stepBusinessAddress").value.trim().length > 0;
    const badge = document.getElementById("homeAddressStepBadge");
    const labelBadge = document.getElementById("homeAddressLabelBadge");
    const explainer = document.getElementById("homeAddressExplainer");
    if (hasBusinessAddress) {
      badge.textContent = "optional"; badge.className = "opt";
      labelBadge.textContent = "optional"; labelBadge.className = "opt";
      explainer.textContent = "You already added a business address \u2014 this is optional.";
    } else {
      badge.textContent = "*required"; badge.className = "req";
      labelBadge.textContent = "*required"; labelBadge.className = "req";
      explainer.textContent = "We need this for verification since you didn't add a business address.";
    }
  }
}

document.getElementById("stepBackBtn").addEventListener("click", () => {
  if (currentStep > 1) goToStep(currentStep - 1);
});

// Role choice selection
document.querySelectorAll(".offer-type-card[data-role]").forEach(card => {
  card.addEventListener("click", () => {
    document.querySelectorAll(".offer-type-card[data-role]").forEach(c => c.classList.remove("selected"));
    card.classList.add("selected");
    selectedUserRole = card.dataset.role;
  });
});

// Offer type selection
document.querySelectorAll(".offer-type-card[data-offer]").forEach(card => {
  card.addEventListener("click", () => {
    document.querySelectorAll(".offer-type-card").forEach(c => c.classList.remove("selected"));
    card.classList.add("selected");
    selectedOfferType = card.dataset.offer;
  });
});

document.getElementById("stepNextBtn").addEventListener("click", async () => {
  const mapping = getStepMapping();
  const panelId = mapping.panels[currentStep - 1];

  if (panelId === 1) {
    if (!selectedUserRole) return safeAlert("Please select how you'd like to use GrowthHub.");
    isFreelancer = selectedUserRole === "freelancer";
    goToStep(currentStep + 1);
    return;
  }
  if (panelId === 2) {
    if (!selectedOfferType) return safeAlert("Please select what you offer.");
    goToStep(currentStep + 1);
    return;
  }
  if (panelId === 3) {
    const name = document.getElementById("stepName").value.trim();
    const email = document.getElementById("stepEmail").value.trim();
    if (!name) return safeAlert("Please enter your name.");
    if (!verifiedPhoneNumber) {
      const justVerified = await checkPhoneVerification();
      if (!justVerified) return safeAlert("Please verify your phone first.");
    }
    if (!email.includes("@") || !email.split("@").pop().includes(".")) return safeAlert("Please enter a valid email.");
    if (isFreelancer) {
      goToStep(currentStep + 1);
    } else {
      goToStep(currentStep + 1);
    }
    return;
  }
  if (panelId === 4) {
    if (!stepperTags.length) return safeAlert("Add at least one service or product.");
    goToStep(currentStep + 1);
    return;
  }
  if (panelId === 5) {
    goToStep(currentStep + 1);
    return;
  }
  if (panelId === 6) {
    if (!uploadedPhotoBase64 && !currentProfile?.id) return safeAlert("Please upload a photo.");
    if (isFreelancer) {
      goToStep(currentStep + 1);
    } else {
      submitRegistration();
    }
    return;
  }

  // Freelancer step 7 -> submit
  submitRegistration();
});

document.getElementById("stepperBack").addEventListener("click", () => showView("profile"));

async function submitRegistration() {
  if (isFreelancer) {
    const homeAddress = document.getElementById("stepHomeAddress").value.trim();
    const businessAddress = document.getElementById("stepBusinessAddress").value.trim();
    if (!homeAddress && !businessAddress) {
      return safeAlert("Add a business address, or a home address if you work from home.");
    }
  }

  const payload = {
    initData: tg.initData,
    name: document.getElementById("stepName").value.trim(),
    email: document.getElementById("stepEmail").value.trim(),
    user_type: isFreelancer ? "freelancer" : "customer",
  };

  if (isFreelancer) {
    payload.services = stepperTags;
    // Defensive filter here too — belt-and-braces alongside the load-time
    // filter above. If sp.handle is ever missing (shouldn't be possible
    // now, but shouldn't crash the whole submit even if it happened),
    // treat it as no handle rather than throwing on undefined.trim().
    payload.social_platforms = socialPlatforms.filter(sp => sp && typeof sp.handle === "string" && sp.handle.trim());
    payload.business_address = document.getElementById("stepBusinessAddress").value.trim();
    payload.website = document.getElementById("stepWebsite").value.trim();
    payload.home_address = document.getElementById("stepHomeAddress").value.trim();
    payload.description = document.getElementById("stepDescription").value.trim();
    payload.business_type = selectedOfferType;
    payload.price = Number(document.getElementById("stepPrice").value) || 0;
    payload.delivery_available = document.getElementById("stepDelivery").checked ? 1 : 0;
  }

  if (uploadedPhotoBase64) payload.photo_base64 = uploadedPhotoBase64;
  else if (currentProfile?.id) payload.keep_existing_photo = true;

  if (userLat != null && userLng != null) {
    payload.lat = userLat;
    payload.lng = userLng;
  }

  const { ok, data } = await apiPost("/api/register", payload);
  if (ok) {
    currentUserType = isFreelancer ? "freelancer" : "customer";
    if (isFreelancer) {
      document.getElementById("successTitle").textContent = "You're Listed!";
      document.getElementById("successDesc").textContent = "Your profile is now visible to people searching for your services.";
    } else {
      document.getElementById("successTitle").textContent = "Welcome!";
      document.getElementById("successDesc").textContent = "You're all set. Start exploring services and freelancers near you.";
    }
    showView("success");
  } else if (data?.error === "phone_not_verified") {
    safeAlert("Phone verification expired — please verify again.");
    goToStep(2);
  } else {
    safeAlert(data?.error === "missing_fields" ? `Missing: ${data.fields.join(", ")}` : "Something went wrong.");
  }
}

// ============================================================
// Theme
// ============================================================
function applyTelegramTheme() {
  if (tg.colorScheme === "dark") {
    document.documentElement.style.setProperty("--bg", "#0F1115");
    document.documentElement.style.setProperty("--surface", "#1A1D24");
    document.documentElement.style.setProperty("--text", "#F5F6FA");
    document.documentElement.style.setProperty("--text-muted", "#9098B1");
    document.documentElement.style.setProperty("--border", "#2A2E3A");
    document.documentElement.style.setProperty("--secondary-soft", "#123531");
    document.documentElement.style.setProperty("--accent-soft", "#3D2E0A");
    document.documentElement.style.setProperty("--danger-soft", "#3D1515");
  }
}
applyTelegramTheme();
tg.onEvent("themeChanged", applyTelegramTheme);

// ============================================================
// ADMIN PANEL
// ============================================================
async function checkAdminAccess() {
  const res = await apiGet("/api/admin/check");
  if (res.is_admin) {
    document.getElementById("adminNavBtn").style.display = "flex";
  }
}

async function loadAdminPanel() {
  const stats = await apiGet("/api/admin/stats");
  if (stats.error) {
    document.getElementById("adminStats").innerHTML = emptyState("No admin access.");
    return;
  }
  document.getElementById("adminStats").innerHTML = `
    <div class="stat-card"><b>${stats.entrepreneurs}</b><span>Entrepreneurs</span></div>
    <div class="stat-card"><b>${stats.services}</b><span>Services</span></div>
    <div class="stat-card"><b>${stats.ratings}</b><span>Ratings</span></div>`;
  await refreshAdminList();
}

async function refreshAdminList() {
  const data = await apiGet("/api/admin/list_admins");
  if (data.error) return;
  
  const renderAdmin = (admin, isRoot = false) => {
    const displayName = admin.name ? escapeHtml(admin.name) : `#${admin.telegramId}`;
    const badge = isRoot
      ? '<span class="admin-badge tier1">Tier 1</span>'
      : '<span class="admin-badge tier2">Tier 2</span>';
    // Tier 1 (root) admins can't be removed here at all — not by
    // another Tier 1 admin, not by anyone — because they're not a
    // database row to delete in the first place; they come straight
    // from ADMIN_IDS in the deploy config. Changing that means editing
    // the env var and redeploying, not an app action, so there's
    // nothing for a Remove button here to even do.
    const removeBtn = isRoot ? "" : `<button class="btn-remove-admin" data-id="${admin.telegramId}">Remove</button>`;
    return `<div class="admin-row"><span class="admin-name">${displayName}${badge}</span>${removeBtn}</div>`;
  };
  
  let html = "";
  if (data.root_admins && data.root_admins.length > 0) {
    html += data.root_admins.map(admin => renderAdmin(admin, true)).join("");
  }
  if (data.added_admins && data.added_admins.length > 0) {
    html += data.added_admins.map(admin => renderAdmin(admin, false)).join("");
  }
  if (!html) html = '<div class="field-hint">No admins found.</div>';
  
  document.getElementById("adminListDisplay").innerHTML = html;
  
  document.querySelectorAll(".btn-remove-admin").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = Number(btn.dataset.id);
      if (!id) return;
      const { ok, data } = await apiPost("/api/admin/remove_admin", { initData: tg.initData, telegram_id: id });
      if (data?.error === "is_root_admin") safeAlert("Root admin — remove via Render.");
      else { safeAlert(ok && data.removed ? "Removed." : "Not found."); if (ok && data.removed) refreshAdminList(); }
    });
  });
}

document.getElementById("adminBack").addEventListener("click", () => showView("profile"));
document.getElementById("adminBroadcastBtn").addEventListener("click", () => {
  const message = document.getElementById("adminBroadcastText").value.trim();
  if (!message) return safeAlert("Write a message first.");
  safeConfirm(`Send to all?\n\n"${message}"`, async (confirmed) => {
    if (!confirmed) return;
    const { ok, data } = await apiPost("/api/admin/broadcast", { initData: tg.initData, message });
    safeAlert(ok ? `Sent to ${data.sent} (${data.failed} failed).` : "Failed.");
    if (ok) document.getElementById("adminBroadcastText").value = "";
  });
});
// Shared between both "make someone an admin" entry points below (by
// Telegram ID directly, and by name/email search) so the two don't
// drift into different wording for the same two error cases.
function addAdminErrorMessage(errorCode) {
  if (errorCode === "already_root_admin") return "Already a Tier 1 admin (set in .env) — nothing to add.";
  if (errorCode === "already_admin") return "Already an admin.";
  return "Error.";
}

document.getElementById("addAdminBtn").addEventListener("click", async () => {
  const id = Number(document.getElementById("adminIdInput").value.trim());
  if (!id) return safeAlert("Enter a valid ID.");
  const { ok, data } = await apiPost("/api/admin/add_admin", { initData: tg.initData, telegram_id: id });
  safeAlert(ok ? "Admin added." : addAdminErrorMessage(data?.error));
  if (ok) { document.getElementById("adminIdInput").value = ""; refreshAdminList(); }
});

// Reuses the same search_listings endpoint Search Listings uses (name/
// email partial match) rather than a second, separate search backend —
// "find a user to promote" and "find a user to moderate" are the exact
// same lookup, just followed by a different action button.
document.getElementById("adminUserSearchBtn").addEventListener("click", async () => {
  const q = document.getElementById("adminUserSearchInput").value.trim();
  const container = document.getElementById("adminUserSearchResults");
  if (!q) { container.innerHTML = ""; return; }
  const data = await apiGet(`/api/admin/search_listings?q=${encodeURIComponent(q)}`);
  const results = (data && data.results) || [];
  if (!results.length) { container.innerHTML = `<p class="field-hint">No matches.</p>`; return; }
  container.innerHTML = results.map(r => `
    <div class="admin-row">
      <span class="admin-name">${escapeHtml(r.name)} <span class="field-hint">(${escapeHtml(r.user_type)})</span></span>
      <button class="btn-small" data-make-admin-id="${r.telegram_id}" data-make-admin-name="${escapeHtml(r.name)}">Make Admin</button>
    </div>`).join("");
  container.querySelectorAll("[data-make-admin-id]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const { ok, data: res } = await apiPost("/api/admin/add_admin", { initData: tg.initData, telegram_id: Number(btn.dataset.makeAdminId) });
      safeAlert(ok ? `${btn.dataset.makeAdminName} added as admin.` : addAdminErrorMessage(res?.error));
      if (ok) { document.getElementById("adminUserSearchInput").value = ""; container.innerHTML = ""; refreshAdminList(); }
    });
  });
});

// ---- Search Listings ----
document.getElementById("adminSearchBtn").addEventListener("click", async () => {
  const q = document.getElementById("adminSearchInput").value.trim();
  if (!q) return;
  const data = await apiGet(`/api/admin/search_listings?q=${encodeURIComponent(q)}`);
  const container = document.getElementById("adminSearchResults");
  const results = data?.results || [];
  if (!results.length) { container.innerHTML = `<p class="field-hint" style="margin-top:8px;">No results.</p>`; return; }
  container.innerHTML = results.map(r => `
    <div class="admin-listing-row" data-id="${r.id}">
      <div><b>#${r.id}</b> ${escapeHtml(r.name)} <span class="field-hint">(${r.user_type})</span></div>
      <div class="field-hint">${r.suspended ? (r.suspended_until ? `SUSPENDED until ${new Date(r.suspended_until).toLocaleString()}` : "SUSPENDED (indefinite)") : "Active"} | ${r.identity_verified ? "Verified" : ""} | ${r.avg_rating ? "\u2b50 " + r.avg_rating : ""}</div>
      <div style="display:flex;gap:6px;margin-top:4px;flex-wrap:wrap;">
        ${r.suspended
          ? `<button class="btn-small btn-green" data-admin-action="unsuspend" data-listing-id="${r.id}">Unsuspend</button>`
          : `<button class="btn-small btn-orange" data-admin-action="suspend" data-listing-id="${r.id}">Suspend</button>`}
        <button class="btn-small" data-admin-action="toggle-feature" data-listing-id="${r.id}" data-feature-value="${!r.force_featured}">${r.force_featured ? "Unfeature" : "Feature"}</button>
        <button class="btn-small danger-text" data-admin-action="remove" data-listing-name="${escapeHtml(r.name)}">Remove</button>
        <button class="btn-small danger-text" data-admin-action="ban" data-listing-id="${r.id}" data-listing-name="${escapeHtml(r.name)}">Ban</button>
      </div>
    </div>`).join("");
  // Wired via addEventListener + data attributes rather than inline
  // onclick="..." strings — entrepreneur ids are Mongo ObjectId strings
  // (24 hex chars), and embedding one unquoted into an onclick attribute
  // (onclick="fn(507f1f77...)") is invalid JS syntax; it threw a syntax
  // error the instant any of these were clicked, silently, with no
  // network request ever sent. Listing names have the same problem for
  // any name containing an apostrophe (breaks the quoted JS string).
  // Reading values from data-* attributes sidesteps both issues.
  container.querySelectorAll("[data-admin-action]").forEach(btn => {
    btn.addEventListener("click", () => {
      const action = btn.dataset.adminAction;
      if (action === "suspend") openSuspendDurationModal(btn.dataset.listingId);
      else if (action === "unsuspend") adminUnsuspend(btn.dataset.listingId);
      else if (action === "toggle-feature") adminToggleFeature(btn.dataset.listingId, btn.dataset.featureValue === "true");
      else if (action === "remove") adminForceRemove(btn.dataset.listingName);
      else if (action === "ban") adminBan(btn.dataset.listingId, btn.dataset.listingName);
    });
  });
});

// Suspend now supports a time-based duration instead of only an
// indefinite toggle — a small modal (same pattern as Post Job / Respond
// elsewhere in this app) rather than cluttering every single search
// result row with a permanently-visible duration picker.
function openSuspendDurationModal(id) {
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-card">
      <h3>Suspend Listing</h3>
      <p class="field-hint">Choose how long this suspension should last.</p>
      <label class="field">Duration
        <select id="suspendDurationSelect">
          <option value="24">24 hours</option>
          <option value="72">3 days</option>
          <option value="168">7 days</option>
          <option value="">Indefinite (manual unsuspend)</option>
        </select>
      </label>
      <button class="btn-primary" id="suspendConfirmBtn">Suspend</button>
      <button class="btn-secondary btn-modal-cancel" id="suspendCancelBtn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  document.getElementById("suspendConfirmBtn").addEventListener("click", async () => {
    const val = document.getElementById("suspendDurationSelect").value;
    overlay.remove();
    const { ok, status, data } = await apiPost(`/api/admin/listings/${id}/suspend`, {
      initData: tg.initData,
      duration_hours: val ? Number(val) : null,
    });
    if (!ok) console.error("adminSuspend failed:", status, data);
    safeAlert(ok ? "Suspended." : "Error.");
    if (ok) document.getElementById("adminSearchBtn").click();
  });
  document.getElementById("suspendCancelBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

// Ban is deliberately more final than Remove — it both wipes the
// listing (same underlying cleanup as Remove) AND records the
// identity so they can't just re-register. Confirmed with an explicit
// warning since, unlike suspend, there's no undo button for this one.
function adminBan(id, name) {
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-card">
      <h3>Ban "${escapeHtml(name)}"</h3>
      <p class="field-hint">This deletes their listing AND blocks their Telegram account from ever registering again. This can't be undone from the app.</p>
      <label class="field">Reason <span class="opt">optional, kept in the audit log</span>
        <input type="text" id="banReasonInput" placeholder="e.g. repeated fake listings" />
      </label>
      <button class="btn-primary" style="background:var(--danger);" id="banConfirmBtn">Ban &amp; Delete</button>
      <button class="btn-secondary btn-modal-cancel" id="banCancelBtn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  document.getElementById("banConfirmBtn").addEventListener("click", async () => {
    const reason = document.getElementById("banReasonInput").value.trim();
    overlay.remove();
    const { ok, status, data } = await apiPost(`/api/admin/listings/${id}/ban`, { initData: tg.initData, reason });
    if (!ok) console.error("adminBan failed:", status, data);
    safeAlert(ok ? "Banned and deleted." : "Error.");
    if (ok) document.getElementById("adminSearchBtn").click();
  });
  document.getElementById("banCancelBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

async function adminUnsuspend(id) {
  const { ok, status, data } = await apiPost(`/api/admin/listings/${id}/unsuspend`, { initData: tg.initData });
  if (!ok) console.error("adminUnsuspend failed:", status, data);
  safeAlert(ok ? "Unsuspended." : "Error.");
  if (ok) document.getElementById("adminSearchBtn").click();
}
async function adminToggleFeature(id, featured) {
  const { ok, status, data } = await apiPost("/api/admin/feature", { initData: tg.initData, listing_id: id, featured });
  if (!ok) console.error("adminToggleFeature failed:", status, data);
  safeAlert(ok ? (featured ? "Featured." : "Unfeatured.") : "Error.");
  if (ok) document.getElementById("adminSearchBtn").click();
}
function adminForceRemove(name) {
  safeConfirm(`Remove "${name}"?`, async (confirmed) => {
    if (!confirmed) return;
    const { ok, status, data } = await apiPost("/api/admin/forceremove", { initData: tg.initData, name });
    if (!ok) console.error("adminForceRemove failed:", status, data);
    safeAlert(ok && data.removed ? "Removed." : "Not found.");
    if (ok) document.getElementById("adminSearchBtn").click();
  });
}

// ---- Audit Log ----
document.getElementById("adminAuditBtn").addEventListener("click", async () => {
  const data = await apiGet("/api/admin/audit_log?limit=30");
  const container = document.getElementById("adminAuditLog");
  if (!data || !data.length) { container.innerHTML = `<p class="field-hint">No entries.</p>`; return; }
  container.innerHTML = data.map(r => `
    <div class="admin-audit-row">
      <span class="field-hint">${r.created_at ? r.created_at.slice(0, 16) : ""}</span>
      <b>${escapeHtml(r.action)}</b>
      <span class="field-hint">${r.target_type ? r.target_type + "#" + (r.target_id || "") : ""}</span>
      ${r.details ? `<span class="field-hint">${escapeHtml(r.details)}</span>` : ""}
    </div>`).join("");
});

// ============================================================
// JOBS / BILLBOARD
// ============================================================
let jobsMode = "open"; // "open" | "mine"
let jobSearchQuery = "";
let jobSearchDebounce = null;
// Cached from the last /api/jobs response so the compose form's on-site
// hint doesn't need its own extra request just to know the radius.
let onSiteRadiusKm = 15;
let onSiteRadiusLabel = "~1h";
let jobDetailReturnView = "jobs";
let currentJobDetailId = null;

document.querySelectorAll("[data-jobtab]").forEach(tab => {
  tab.addEventListener("click", () => {
    jobsMode = tab.dataset.jobtab;
    document.querySelectorAll("[data-jobtab]").forEach(t => t.classList.toggle("active", t === tab));
    document.getElementById("jobSearchBar").style.display = jobsMode === "mine" ? "none" : "flex";
    loadJobs();
  });
});

document.getElementById("jobSearchInput").addEventListener("input", (e) => {
  clearTimeout(jobSearchDebounce);
  jobSearchDebounce = setTimeout(() => {
    jobSearchQuery = e.target.value.trim();
    loadJobs();
  }, 300);
});

async function loadJobs() {
  const container = document.getElementById("jobsResults");
  container.innerHTML = `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">Loading...</p>`;

  if (jobsMode === "mine") {
    const jobs = asArray(await apiGet("/api/jobs/mine"));
    renderJobList(jobs, true);
    return;
  }

  const params = new URLSearchParams();
  if (jobSearchQuery) params.set("q", jobSearchQuery);
  if (userLat != null && userLng != null) { params.set("lat", userLat); params.set("lng", userLng); }
  const data = await apiGet(`/api/jobs?${params.toString()}`);
  if (data && data.on_site_radius_km != null) {
    onSiteRadiusKm = data.on_site_radius_km;
    onSiteRadiusLabel = data.on_site_radius_estimate_label || onSiteRadiusLabel;
  }
  renderJobList(asArray(data?.results || data), false);
}

function jobBudgetLabel(job) {
  if (job.budget_type === "negotiable" || job.budget == null) return "Negotiable";
  const amount = Number(job.budget).toLocaleString();
  return job.budget_type === "hourly" ? `\u20a6${amount}/hr` : `\u20a6${amount}`;
}

function renderJobList(jobs, mine) {
  const container = document.getElementById("jobsResults");
  if (!jobs.length) {
    container.innerHTML = emptyState(mine ? "You haven't posted any jobs yet." : "No open jobs right now — check back soon, or be the first to post one.");
    return;
  }
  container.innerHTML = jobs.map(j => renderJobCard(j, mine)).join("");
  container.querySelectorAll("[data-open-job]").forEach(card => {
    card.addEventListener("click", () => openJobDetail(card.dataset.openJob));
  });
}

function renderJobCard(job, mine) {
  const statusClass = job.status === "open" ? "job-status-open" : "job-status-fulfilled";
  const metaBits = [];
  if (job.category) metaBits.push(escapeHtml(job.category));
  if (job.distance_km != null) {
    // Distance is the real number (from actual haversine math); the
    // minutes figure next to it is a rough, static-speed estimate for
    // orientation only — see lib/travelTime.js on the backend for
    // exactly what that assumes and why it's deliberately conservative.
    const timePart = job.travel_estimate_label ? ` \u00b7 ${job.travel_estimate_label} (traffic permitting)` : "";
    metaBits.push(`${job.distance_km}km away${timePart}`);
  } else if (job.location) metaBits.push(escapeHtml(job.location));
  metaBits.push(`${job.response_count} response${job.response_count === 1 ? "" : "s"}`);

  return `
    <div class="job-card" data-open-job="${job.id}">
      <div class="job-card-top">
        <h3>${escapeHtml(job.title)}</h3>
        <span class="job-budget-badge">${jobBudgetLabel(job)}</span>
      </div>
      <p class="job-card-desc">${escapeHtml(job.description)}</p>
      <div class="job-card-meta">
        ${mine ? `<span class="job-status-badge ${statusClass}">${escapeHtml(job.status)}</span>` : ""}
        <span>${metaBits.join(" · ")}</span>
      </div>
    </div>`;
}

document.getElementById("postJobBtn").addEventListener("click", () => openPostJobModal());

function openPostJobModal() {
  // Prefer the address the user already saved on their own profile over
  // making them type it again — same "smart default, still editable"
  // pattern used for the poster-name field. Falls back to their live
  // browser location only if they never saved one, and to nothing (a
  // blank field) if neither exists.
  const savedAddress = currentProfile?.business_address || currentProfile?.home_address || "";
  const savedLoc = currentProfile?.saved_location || null;

  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-card">
      <h3>Post a Job</h3>
      <p class="field-hint">Describe what you need — freelancers on GrowthHub can respond directly.</p>
      <label class="field">Title
        <input type="text" id="jobTitleInput" placeholder="e.g. Need a logo designed" maxlength="120" />
      </label>
      <label class="field">Description
        <textarea id="jobDescInput" rows="4" placeholder="What do you need done? Be specific." maxlength="1000"></textarea>
      </label>
      <label class="field">Category <span class="opt">optional</span>
        <input type="text" id="jobCategoryInput" placeholder="e.g. design, plumbing, tutoring" />
      </label>
      <label class="field">Budget type
        <select id="jobBudgetType">
          <option value="negotiable">Negotiable</option>
          <option value="fixed">Fixed price</option>
          <option value="hourly">Hourly rate</option>
        </select>
      </label>
      <label class="field" id="jobBudgetAmountField" style="display:none;">Budget amount (\u20a6)
        <input type="number" id="jobBudgetAmount" placeholder="e.g. 15000" />
      </label>
      <label class="field-toggle">
        <span>This must be done on-site (in person)?</span>
        <input type="checkbox" id="jobRequiresOnSite" />
      </label>
      <p class="field-hint" id="jobOnSiteHint" style="display:none;">Only shown to freelancers within ${onSiteRadiusKm}km (${onSiteRadiusLabel}, traffic permitting) who've also shared their location.</p>
      <label class="field" id="jobLocationField" style="display:none;">Location
        <input type="text" id="jobLocationInput" placeholder="e.g. Ikeja, Lagos" value="${escapeHtml(savedAddress)}" />
        ${savedAddress ? `<span class="field-hint">Filled in from your saved profile address — edit if this job is somewhere else.</span>` : ""}
      </label>
      <button class="btn-primary" id="jobPostSubmitBtn">Post Job</button>
      <button class="btn-secondary btn-modal-cancel" id="jobPostCancelBtn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  document.getElementById("jobBudgetType").addEventListener("change", (e) => {
    document.getElementById("jobBudgetAmountField").style.display = e.target.value === "negotiable" ? "none" : "block";
  });
  document.getElementById("jobRequiresOnSite").addEventListener("change", (e) => {
    document.getElementById("jobLocationField").style.display = e.target.checked ? "block" : "none";
    document.getElementById("jobOnSiteHint").style.display = e.target.checked ? "block" : "none";
  });

  document.getElementById("jobPostSubmitBtn").addEventListener("click", async () => {
    const title = document.getElementById("jobTitleInput").value.trim();
    const description = document.getElementById("jobDescInput").value.trim();
    if (!title || !description) {
      return safeAlert("Please add a title and description.");
    }
    const requiresOnSite = document.getElementById("jobRequiresOnSite").checked;
    const locationAddress = document.getElementById("jobLocationInput").value.trim();
    if (requiresOnSite && !locationAddress) {
      return safeAlert("On-site jobs need a location so nearby freelancers can find them.");
    }

    const payload = {
      initData: tg.initData,
      title,
      description,
      category: document.getElementById("jobCategoryInput").value.trim(),
      budget_type: document.getElementById("jobBudgetType").value,
      budget: document.getElementById("jobBudgetAmount").value || null,
      requires_on_site: requiresOnSite,
      location_address: locationAddress,
    };
    // Saved profile location wins over live GPS here on purpose — the
    // request was specifically "use the saved profile location," and a
    // device's current GPS position isn't necessarily where the JOB is
    // (someone could be posting from their phone at work about a job at
    // home). Live GPS only steps in as a fallback if there's no saved
    // location at all.
    const jobLoc = savedLoc || (userLat != null && userLng != null ? { lat: userLat, lng: userLng } : null);
    if (jobLoc) { payload.lat = jobLoc.lat; payload.lng = jobLoc.lng; }

    const { ok, data } = await apiPost("/api/jobs", payload);
    if (ok) {
      overlay.remove();
      safeAlert("Job posted! You'll see responses under My Jobs.");
      jobsMode = "open";
      document.querySelectorAll("[data-jobtab]").forEach(t => t.classList.toggle("active", t.dataset.jobtab === "open"));
      loadJobs();
    } else {
      safeAlert(data?.error === "missing_fields" ? `Missing: ${data.fields.join(", ")}` : "Something went wrong.");
    }
  });

  document.getElementById("jobPostCancelBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

async function openJobDetail(jobId) {
  const activeView = document.querySelector(".view.active");
  if (activeView && activeView.id !== "view-job-detail") {
    jobDetailReturnView = activeView.id.replace("view-", "");
  }
  currentJobDetailId = jobId;
  showView("job-detail");

  const container = document.getElementById("jobDetailContent");
  container.innerHTML = `<p style="text-align:center;color:var(--text-muted);padding:40px 0;">Loading...</p>`;

  const job = await apiGet(`/api/jobs/${jobId}`);
  if (!job || job.error) {
    container.innerHTML = emptyState("This job couldn't be found.");
    return;
  }

  const myId = tg.initDataUnsafe?.user?.id;
  const isOwner = job.poster_telegram_id === myId;
  const metaBits = [];
  if (job.category) metaBits.push(escapeHtml(job.category));
  if (job.location) metaBits.push(escapeHtml(job.location));
  metaBits.push(`Posted by ${escapeHtml(job.poster_name || "Someone")}`);

  let responsesHtml = "";
  if (isOwner) {
    const responses = job.responses || [];
    responsesHtml = `
      <div class="detail-section">
        <div class="detail-section-title">Responses (${responses.length})</div>
        ${responses.length
          ? responses.map(r => `
            <div class="job-response-row">
              <div class="job-response-head"><b>${escapeHtml(r.name)}</b></div>
              ${r.message ? `<p>${escapeHtml(r.message)}</p>` : `<p class="field-hint">No message left.</p>`}
            </div>`).join("")
          : `<p class="field-hint">No responses yet.</p>`}
      </div>`;
  }

  let actionsHtml = "";
  if (isOwner && job.status === "open") {
    actionsHtml = `
      <div class="job-post-actions">
        <button class="btn-primary" id="jobMarkFulfilledBtn">Mark Fulfilled</button>
        <button class="btn-secondary danger-text" id="jobCloseBtn">Close</button>
      </div>
      <div class="job-post-actions">
        <button class="btn-secondary danger-text" id="jobDeleteBtn" style="width:100%;">Delete Job</button>
      </div>`;
  } else if (isOwner) {
    actionsHtml = `
      <div class="job-post-actions">
        <button class="btn-secondary danger-text" id="jobDeleteBtn" style="width:100%;">Delete Job</button>
      </div>`;
  } else if (job.status === "open") {
    actionsHtml = `
      <div class="job-post-actions">
        <button class="btn-primary" id="jobRespondBtn" style="width:100%;">Respond to this Job</button>
      </div>`;
  }

  container.innerHTML = `
    <h2 class="job-detail-title">${escapeHtml(job.title)}</h2>
    <div class="job-card-meta" style="margin-bottom:14px;">
      <span class="job-budget-badge">${jobBudgetLabel(job)}</span>
      <span class="job-status-badge ${job.status === "open" ? "job-status-open" : "job-status-fulfilled"}">${escapeHtml(job.status)}</span>
    </div>
    <p class="job-detail-desc">${escapeHtml(job.description)}</p>
    <p class="field-hint" style="margin-bottom:16px;">${metaBits.join(" · ")}</p>
    ${responsesHtml}
    ${actionsHtml}`;

  if (isOwner && job.status === "open") {
    document.getElementById("jobMarkFulfilledBtn").addEventListener("click", () => closeJob(jobId, "fulfilled"));
    document.getElementById("jobCloseBtn").addEventListener("click", () => closeJob(jobId, "closed"));
  }
  const deleteBtn = document.getElementById("jobDeleteBtn");
  if (deleteBtn) deleteBtn.addEventListener("click", () => deleteJob(jobId));
  const respondBtn = document.getElementById("jobRespondBtn");
  if (respondBtn) respondBtn.addEventListener("click", () => openRespondModal(jobId));
}

document.getElementById("jobDetailBack").addEventListener("click", () => showView(jobDetailReturnView));

function openRespondModal(jobId) {
  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = `
    <div class="modal-card">
      <h3>Respond to this Job</h3>
      <p class="field-hint">Let the poster know you're interested — a short note helps.</p>
      <textarea id="jobRespondMessage" rows="3" placeholder="Optional — introduce yourself or ask a question" maxlength="300"></textarea>
      <button class="btn-primary" id="jobRespondSubmitBtn">Send Response</button>
      <button class="btn-secondary btn-modal-cancel" id="jobRespondCancelBtn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  document.getElementById("jobRespondSubmitBtn").addEventListener("click", async () => {
    const message = document.getElementById("jobRespondMessage").value.trim();
    overlay.remove();
    const { ok, data } = await apiPost(`/api/jobs/${jobId}/respond`, { initData: tg.initData, message });
    if (ok) {
      safeAlert("Response sent!");
    } else {
      const messages = {
        already_responded: "You've already responded to this job.",
        own_post: "You can't respond to your own job post.",
        not_open: "This job isn't open anymore.",
        not_found: "This job couldn't be found.",
      };
      safeAlert(messages[data?.error] || "Something went wrong.");
    }
  });

  document.getElementById("jobRespondCancelBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

function closeJob(jobId, status) {
  const label = status === "fulfilled" ? "mark this job as fulfilled" : "close this job";
  safeConfirm(`Are you sure you want to ${label}?`, async (confirmed) => {
    if (!confirmed) return;
    // FIX: this called apiPatch() against a route that's deliberately
    // POST-only (see the note in the backend's routes/jobRoutes.js —
    // this app standardized on POST everywhere specifically to avoid
    // this exact mismatch, after the same bug bit the admin panel's
    // suspend/unsuspend buttons earlier). PATCH here always 404'd.
    const { ok, status: httpStatus, data } = await apiPost(`/api/jobs/${jobId}/close`, { initData: tg.initData, status });
    if (ok) {
      safeAlert("Updated.");
      openJobDetail(jobId);
    } else {
      console.error("closeJob failed:", httpStatus, data);
      safeAlert("Something went wrong.");
    }
  });
}

function deleteJob(jobId) {
  safeConfirm("Delete this job post? This can't be undone.", async (confirmed) => {
    if (!confirmed) return;
    // FIX: two problems here — apiDelete() sent DELETE (the route is
    // POST-only, same reasoning as closeJob() above), AND the URL was
    // missing the "/delete" suffix the backend actually expects
    // (POST /api/jobs/:id/delete, not DELETE /api/jobs/:id).
    const { ok, status: httpStatus, data } = await apiPost(`/api/jobs/${jobId}/delete`, { initData: tg.initData });
    if (ok) {
      safeAlert("Job deleted.");
      showView(jobDetailReturnView);
    } else {
      console.error("deleteJob failed:", httpStatus, data);
      safeAlert("Something went wrong.");
    }
  });
}

// ---- Boot ----
async function boot() {
  // FIX: checkAdminAccess() used to be called only inside the
  // "already registered" branch below. An admin who hasn't registered
  // a listing yet would never have their admin status checked, no
  // matter what ADMIN_IDS says — the Admin tab would just never appear
  // for them. Moving this above the if/else means it always runs,
  // regardless of registration status.
  checkAdminAccess();

  const profile = await apiGet("/api/profile");
  if (profile && !profile.error && profile.id) {
    currentUserType = profile.user_type || "freelancer";
    loadHome();
  } else {
    openStepper(null);
  }
}
let currentUserType = null;
boot();